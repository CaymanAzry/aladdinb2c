<?php

/*
|--------------------------------------------------------------------------
| Cache Themes
|--------------------------------------------------------------------------
|
| corals/theme reads themes settings from json files inside
| each theme's folder. We will cache them in a single php file to
| avoid searching the filesystem for each Request. You can use
| 'theme:refresh-cache' to rebuild cache, or set config/themes.php
| 'cache' setting to false to disable completely
|
*/

return array (
  0 => 
  array (
    'name' => 'corals-admin',
    'assetPath' => 'assets/themes/admin',
    'extends' => NULL,
    'type' => 'admin',
    'caption' => 'Corals Admin',
    'version' => '2.4.1',
    'viewsPath' => 'admin',
  ),
  1 => 
  array (
    'name' => 'corals-admin-blue',
    'assetPath' => 'assets/themes/admin-blue',
    'extends' => 'corals-admin',
    'type' => 'admin',
    'caption' => 'Corals Admin Blue',
    'version' => '1.4',
    'viewsPath' => 'admin-blue',
  ),
  2 => 
  array (
    'name' => 'corals-admin-orange',
    'assetPath' => 'assets/themes/admin-orange',
    'extends' => 'corals-admin',
    'type' => 'admin',
    'caption' => 'Corals Admin Orange',
    'version' => '1.3',
    'viewsPath' => 'admin-orange',
  ),
  3 => 
  array (
    'name' => 'corals-admin-white',
    'assetPath' => 'assets/themes/admin-white',
    'extends' => 'corals-admin',
    'type' => 'admin',
    'caption' => 'Corals Admin White',
    'version' => '1.4',
    'viewsPath' => 'admin-white',
  ),
  4 => 
  array (
    'name' => 'corals-basic',
    'assetPath' => 'assets/themes/cms',
    'extends' => NULL,
    'type' => 'frontend',
    'caption' => 'Corals CMS',
    'version' => '1.4',
    'css' => 
    array (
      0 => 'css/bootstrap.min.css',
      1 => 'css/font-awesome.min.css',
      2 => 'css/animate.min.css',
      3 => 'css/prettyPhoto.css',
      4 => 'css/pricingTable.min.css',
      5 => 'css/main.css',
      6 => 'css/responsive.css',
    ),
    'js' => 
    array (
      0 => 'js/jquery.js',
      1 => 'js/bootstrap.min.js',
      2 => 'js/jquery.prettyPhoto.js',
      3 => 'js/jquery.isotope.min.js',
      4 => 'js/wow.min.js',
      5 => 'js/functions.js',
      6 => 'js/main.js',
    ),
    'viewsPath' => 'cms',
  ),
  5 => 
  array (
    'name' => 'corals-marketplace-marty',
    'assetPath' => 'assets/themes/marketplace-marty',
    'extends' => NULL,
    'type' => 'frontend',
    'caption' => 'Corals Marketplace Marty',
    'version' => '2.5.2',
    'css' => 
    array (
      0 => 'css/bootstrap/bootstrap.min.css',
      1 => 'css/style.css',
      2 => 'css/custom.css',
    ),
    'js' => 
    array (
      0 => 'js/vendor/jquery/jquery-1.12.3.js',
      1 => 'js/vendor/bootstrap.min.js',
      2 => 'js/dashboard.js',
      3 => 'js/main.js',
    ),
    'platform' => 'Marketplace',
    'viewsPath' => 'marketplace-marty',
  ),
  6 => 
  array (
    'name' => 'corals-marketplace-master',
    'assetPath' => 'assets/themes/marketplace-master',
    'extends' => NULL,
    'type' => 'frontend',
    'caption' => 'Corals Marketplace Master',
    'version' => '3.7.1',
    'css' => 
    array (
      0 => 'font-awesome-4.7.0/css/font-awesome.min.css',
      1 => 'css/vendor.min.css',
      2 => 'css/styles.css',
      3 => 'plugins/Ladda/ladda-themeless.min.css',
      4 => 'css/custom.css',
    ),
    'js' => 
    array (
      0 => 'js/modernizr.min.js',
      1 => 'js/vendor.min.js',
      2 => 'js/scripts.min.js',
      3 => 'plugins/Ladda/spin.min.js',
      4 => 'plugins/Ladda/ladda.min.js',
      5 => 'js/functions.js',
      6 => 'js/main.js',
    ),
    'platform' => 'Marketplace',
    'viewsPath' => 'marketplace-master',
  ),
  7 => 
  array (
    'name' => 'corals-marketplace-pro',
    'assetPath' => 'assets/themes/marketplace-pro',
    'extends' => NULL,
    'type' => 'frontend',
    'caption' => 'Corals Marketplace Pro',
    'version' => '2.5.2',
    'css' => 
    array (
      0 => 'font-awesome-4.7.0/css/font-awesome.min.css',
      1 => 'css/vendor.min.css',
      2 => 'css/styles.css',
      3 => 'plugins/Ladda/ladda-themeless.min.css',
      4 => 'css/custom.css',
    ),
    'js' => 
    array (
      0 => 'js/scripts.min.js',
      1 => 'js/functions.js',
      2 => 'js/theme.js',
    ),
    'platform' => 'Marketplace',
    'viewsPath' => 'marketplace-pro',
  ),
  8 => 
  array (
    'name' => 'corals-quantum-admin',
    'assetPath' => 'assets/themes/quantum',
    'extends' => NULL,
    'type' => 'admin',
    'caption' => 'Corals Quantum Admin',
    'version' => '2.4.1',
    'platform' => 'Subscription',
    'viewsPath' => 'quantum',
  ),
);