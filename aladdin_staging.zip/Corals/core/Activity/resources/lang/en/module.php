<?php


return [
    'activity' => [
        'title' => 'Activities',
        'title_singular' => 'Activity',
    ],
];