<?php


return [
    'activity' => [
        'log_name' => 'السجل',
        'subject_type' => 'نموذج',
        'subject_id' => 'رقم النموذج',
        'causer_id' => 'المستخدم',
        'description' => 'الوصف',
        'properties' => 'الخصائص',
    ],
];