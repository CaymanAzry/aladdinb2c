<?php


return [
    'activity' => [
        'title' => 'الأنشطة',
        'title_singular' => 'نشاط',
    ],
];