<?php

return [

    'activity' => [
        'title' => 'actividades',
        'title_singular' => 'Atividade',
    ],

];