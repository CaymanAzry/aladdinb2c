"use strict";
window.initFunctions = ['initTabHash', 'initCkeditor'];
