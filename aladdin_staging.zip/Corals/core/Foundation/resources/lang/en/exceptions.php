<?php

return [
    '403' => "Forbidden! You don't have permission to access."
];