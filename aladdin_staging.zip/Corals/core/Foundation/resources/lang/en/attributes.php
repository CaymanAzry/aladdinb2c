<?php

return [
    'created_at' => 'Created at',
    'updated_at' => 'Updated at',
    'deleted_at' => 'Deleted at',
    'created_by' => 'Created by',
    'id' => 'ID',
    'status' => 'Status',
    'status_options' => [
        'active' => 'Active',
        'inactive' => 'Inactive',
    ],
    'status_options_boolean' => [
        0 => 'Inactive',
        1 => 'Active',
    ],

];