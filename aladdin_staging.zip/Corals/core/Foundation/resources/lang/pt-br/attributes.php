<?php

return [

    'created_at' => 'Criado em',
    'updated_at' => 'Atualizado em',
    'deleted_at' => 'Excluído em',
    'id' => 'identidade',
    'status' => 'Status',
    'status_options' => [
        'active' => 'Ativo',
        'inactive' => 'Inativo',
    ],


];