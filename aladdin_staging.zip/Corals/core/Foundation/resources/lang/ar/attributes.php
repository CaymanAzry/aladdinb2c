<?php

return [
    'created_at' => 'أنشئت في',
    'updated_at' => 'تم تحديثها في',
    'deleted_at' => 'حذفت في',
    'action' => 'الحدث',
    'id' => 'ID',
    'status' => 'الحالة',
    'status_options' => [
        'active' => 'نشط',
        'inactive' => 'غير نشط',
    ]

];