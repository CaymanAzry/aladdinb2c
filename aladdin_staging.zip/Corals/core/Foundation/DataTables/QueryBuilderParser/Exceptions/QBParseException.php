<?php


namespace Corals\Foundation\DataTables\QueryBuilderParser\Exceptions;


class QBParseException extends \Exception
{
}