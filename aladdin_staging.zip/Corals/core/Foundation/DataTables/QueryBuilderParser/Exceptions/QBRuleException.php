<?php


namespace Corals\Foundation\DataTables\QueryBuilderParser\Exceptions;


class QBRuleException extends \Exception
{
}