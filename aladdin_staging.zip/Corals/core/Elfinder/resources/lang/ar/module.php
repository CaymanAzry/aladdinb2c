<?php

return [
    'elfinder' => [
        'title' => 'مدير الملفات'
    ]
];