<?php

return [
    'elfinder' => [
        'title' => 'Files Manager'
    ]
];