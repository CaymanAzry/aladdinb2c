<?php


return [
    'menu' => [
        'title' => 'القوائم',
        'title_singular' => 'القائمة'
    ]
];