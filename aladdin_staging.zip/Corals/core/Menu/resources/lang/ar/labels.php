<?php

return [
    'root_menu_title' => 'القائمة الأصلية [:title]',
    'parent_menu_title' => '[:title] عنصر القائمة الفرعية',
    'menu_item_title' => 'عنصر القائمة [:title]',
    'create_sub' => 'انشاء الفرع',
];