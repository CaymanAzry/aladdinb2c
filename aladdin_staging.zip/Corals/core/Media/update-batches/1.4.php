<?php


Illuminate\Support\Facades\Schema::table('media', function (\Illuminate\Database\Schema\Blueprint $table) {
    $table->text('responsive_images');
});

